/**
 * 
 */
package tutorial;

/**
 * @author Gordon Fraser
 *
 */
public abstract class Owner {

}
